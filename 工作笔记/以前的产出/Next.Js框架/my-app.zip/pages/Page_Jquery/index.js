import $ from "jquery";
import Page_Nav from '../Page_Nav';

const change = ()=>{
    let value = Number($("h2>span")[0].innerText)
    value = isNaN(value)?0:value+1
    console.log($("h2>span")[0].innerText)
    $("h2>span")[0].innerText = value
}

export default function Page_Jquery(){
    return (
        <div>
            <Page_Nav defaultKey={3}/>
            <br/>
            <h1>点击小游戏</h1>
            <h2>你点击了<span>0</span>次</h2>
            <input type="button" onClick={change} value="点我"/>
        </div>
    )
}