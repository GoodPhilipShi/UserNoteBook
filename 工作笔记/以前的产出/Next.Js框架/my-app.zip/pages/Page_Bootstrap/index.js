import { Table } from "react-bootstrap";
import Page_Nav from "../Page_Nav"

export default function Page_Bootstrap() {
    return (
        <div>
            <Page_Nav defaultKey={1}/>
            <br/>
            <Table striped bordered hover variant="dark">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Api使用方法</th>
                        <th>响应</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>GET/POST请求: 信息返回</td>
                        <td>返回提交的信息</td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>POST请求: 加法</td>
                        <td>返回提交的数据的和</td>
                    </tr>
                    <tr>
                        <td colSpan={3}>请到Axios例子下面使用</td>
                    </tr>
                </tbody>
            </Table>
        </div>
    );
}
