import Head from "next/head";
import { Nav } from "react-bootstrap";
import { useEffect,useState } from "react";

const config = [
    { eventKey: "link-1", title: "介绍页面", href:"/Page_About/" },
    {
        eventKey: "link-2",
        title: "Bootstrap 例子",
        href:"/Page_Bootstrap/"
    },
    {
        eventKey: "link-3",
        title: "Ant Design 例子",
        href:"/Page_Antd/"
    },
    { eventKey: "link-4", title: "JQuery 例子", href:"/Page_Jquery/" },
    { eventKey: "link-5", title: "Axios 例子" ,href:"/Page_Axios/"},
];

export default function Page_Nav(props) {
    const defaultNav = config[props.defaultKey].eventKey;
    const [nav,setNav] = useState(defaultNav)
    useEffect(()=>{
        const {defaultKey} = props;
        setNav(config[defaultKey].eventKey)
    })
    return (
        <div>
            <Head>
                <title>后台管理 - Next.Js 框架</title>
            </Head>

            <Nav
                variant="pills"
                defaultActiveKey={nav}
            >
                {config.map((items, index) => {
                    return (
                        <Nav.Item key={index}>
                            <Nav.Link eventKey={items.eventKey} href={items.href}>
                                {items.title}
                            </Nav.Link>
                        </Nav.Item>
                    );
                })}
            </Nav>
        </div>
    );
}
