import axios from "axios";
import { Input, Select, AutoComplete, Button, Divider } from "antd";
const { Option } = Select;
import { useState } from "react";
import Page_Nav from "../Page_Nav";

var method = "",
    url = "",
    params = new Object();

function requests(data) {
    console.log(data);
    return data.method.toLowerCase() == "get"
        ? axios.get(data.url, { params: data.params })
        : data.method.toLowerCase() == "post"
        ? axios.post(data.url, data.params)
        : "";
}

export default function Page_Axios() {
    const [html, setHtml] = useState("");
    return (
        <div>
            <Page_Nav defaultKey={4} />
            <br />
            <h2>这里是Axios的例子</h2>
            <Input.Group compact>
                <Select
                    defaultValue="None"
                    onSelect={(value) => {
                        if (!value) return;
                        method = value;
                    }}
                >
                    <Option value="None">请选择HTTP访问方式</Option>
                    <Option value="Get">GET</Option>
                    <Option value="Post">POST</Option>
                </Select>
                <AutoComplete
                    style={{ width: "20%" }}
                    placeholder="访问链接"
                    onSelect={(value) => {
                        if (!value) return;
                        url = value;
                    }}
                    options={[
                        { value: "/api/Page_Bootstrap" },
                        { value: "/api/Info_add" },
                    ]}
                />
                <AutoComplete
                    style={{ width: "50%" }}
                    placeholder="请求数据, 例如: id=21&cid=92"
                    onChange={(value) => {
                        if (!value) return;
                        params = new Object();
                        let param = value.split("&");
                        if (param.length > 0) {
                            param.map((items, index) => {
                                let p = items.split("=", 2);
                                if (p.length > 0) {
                                    params[p[0]] = p.length == 2 ? p[1] : "";
                                }
                            });
                        } else {
                            params = new Object();
                        }
                    }}
                />
                <Button
                    style={{ width: "20%" }}
                    type="primary"
                    onClick={() => {
                        requests({ url: url, params: params, method: method })
                            .then(function (response) {
                                setHtml(
                                    <div>
                                        <h4>
                                            API信息: {response.data.message}
                                        </h4>
                                        <h4>
                                            访问方式: {response.data.method}
                                        </h4>
                                        <h4>请求数据: {response.data.data}</h4>
                                    </div>
                                );
                            })
                            .catch(function (error) {
                                setHtml(
                                    <div>
                                        发生了不好的事情: {error.message}{" "}
                                    </div>
                                );
                            });
                    }}
                >
                    访问
                </Button>
            </Input.Group>
            <Divider dashed />
            {html}
        </div>
    );
}
