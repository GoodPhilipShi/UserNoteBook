export default (req, res) => {
    res.statusCode = 200;
    res.setHeader("Content-Type", "application/json");
    res.end(
        JSON.stringify({
            message: "这里是返回请求信息Api",
            method: `当前为${req.method}`,
            data: `请求信息如下: ${JSON.stringify(req.method == "GET"?req.query:req.body)}`,
        })
    );
};
