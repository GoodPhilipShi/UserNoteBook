export default (req, res) => {
    let num;
    if(req.method == "POST"){
        res.statusCode = 200;
        res.setHeader("Content-Type", "application/json");
        let values = Object.values(req.body)
        num = 0
        for(let value of values){
            num += Number(value)
        }
    }
    res.end(
        JSON.stringify({
            message: `这里是加法Api, 结果: ${isNaN(num)?"参数不正确":num}`,
            method: `当前为${req.method}`,
            data: `请求信息如下: ${JSON.stringify(req.method == "GET"?req.query:req.body)}`,
        })
    );
};