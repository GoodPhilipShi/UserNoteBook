import Page_About from "./Page_About";

export default () => {
    return (
        <div>
            <Page_About/>
        </div>
    );
}
