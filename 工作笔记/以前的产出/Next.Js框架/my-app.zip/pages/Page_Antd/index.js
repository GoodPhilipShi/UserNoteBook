import { Table } from "antd";
import { useState } from "react";
import Page_Nav from '../Page_Nav'


const columns = [
    {
        title: "返工单号",
        dataIndex: "num",
        key: "num",
        render: (text) => <a>{text}</a>,
    },
    {
        title: "创建时间",
        dataIndex: "originTime",
        key: "originTime",
    },
    {
        title: "返工类型",
        dataIndex: "type",
        key: "type",
    },
    {
        title: "返工状态",
        dataIndex: "status",
        key: "status",
    },
    {
        title: "完工时间",
        key: "diedTime",
        dataIndex: "diedTime",
    },
    {
        title: "备注",
        key: "remark",
        dataIndex: "remark",
    },
];

const datas = [
    {
        key: "1",
        num: "0001",
        originTime: "2021-07-20",
        type: "type1",
        status: "完成",
        diedTime: "2021-12-31",
        remark: "无",
    },
    {
        key: "2",
        num: "0002",
        originTime: "2021-07-20",
        type: "type1",
        status: "未完成",
        diedTime: "2021-12-31",
        remark: "无",
    },
    {
        key: "3",
        num: "0003",
        originTime: "2021-07-20",
        type: "type1",
        status: "完成",
        diedTime: "2021-12-31",
        remark: "无",
    },
];

export default function Page_Antd() {
    const [data, setData] = useState(datas);
    return (
        <div>
            <Page_Nav defaultKey={2}/>
            <br/>
            <input
                id="inputKey"
                style={{ width: "400px" }}
                placeholder="请输入搜索内容(支持返工单号、返工状态、备注)"
                className="tableSearch"
                onKeyDown={(e) => {
                    if (e.key == "Enter") {
                        let key = e.target.value;
                        let tmp = datas.filter((items) => {
                            return (
                                items.key.search(key) != -1 ||
                                items.num.search(key) != -1 ||
                                items.status.search(key) != -1 ||
                                items.remark.search(key) != -1
                            );
                        });
                        if (tmp.length < 1) {
                            alert("不存在该返工单,请核对后重新输入");
                            setData(datas);
                        } else {
                            setData(tmp);
                        }
                    }
                }}
            ></input>
            <input
                type="button"
                value="查询"
                onClick={(e) => {
                    let key = e.target.previousSibling.value;
                    let tmp = datas.filter((items) => {
                        console.log(`->${items.status}<-`)
                        return (
                            items.key.search(key) != -1 ||
                            items.num.search(key) != -1 ||
                            items.status.search(key) != -1 ||
                            items.remark.search(key) != -1
                        );
                    });
                    if (tmp.length < 1) {
                        alert("不存在该返工单,请核对后重新输入");
                        setData(datas);
                    } else {
                        setData(tmp);
                    }
                }}
            />
            <input
                type="button"
                value="重置"
                onClick={(e) => {
                    e.target.previousSibling.previousSibling.value = "";
                    setData(datas);
                }}
            />
            <br />
            <br />
            <Table columns={columns} dataSource={data} className="table" />
        </div>
    );
}
