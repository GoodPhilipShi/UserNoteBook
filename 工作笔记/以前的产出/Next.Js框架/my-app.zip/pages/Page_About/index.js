import { Card, Container, Row, Col } from "react-bootstrap";
import Page_Nav from '../Page_Nav';
import Link from 'next/link';

const configAbout = [
    {
        imgVariant: "top",
        imgSrc: "https://www.linuxprobe.com/wp-content/uploads/2020/01/22.jpg",
        title: "Bootstrap 例子",
        text: "基于 Next.Js 框架 和 React-Boostrap 组件写的例子 -- Api列表",
        href:"/Page_Bootstrap/"
    },
    {
        imgVariant: "top",
        imgSrc: "http://img.yang16.com/2017/12/29/ant3.jpg",
        title: "Ant Design 例子",
        text: "基于 Next.Js 框架 和 Ant Design 组件写的例子 -- 集模糊检索为一体的列表",
        href:"/Page_Antd/"
    },
    {
        imgVariant: "top",
        imgSrc: "http://hiphotos.baidu.com/doc/pic/item/377adab44aed2e7319dac6aa8e01a18b87d6fa01.jpg",
        title: "JQuery 例子",
        text: "基于 Next.Js 框架 和 JQuery.js 写的例子 -- 点击小游戏",
        href:"/Page_Jquery/"
    },
    {
        imgVariant: "top",
        imgSrc: "https://pic3.zhimg.com/v2-53b2461728c36dc315b7e054e070886f.jpg",
        title: "Axios 例子",
        text: "基于 Next.Js 框架 和 Axios HTTP 库 写的例子 -- POST/GET请求",
        href:"/Page_Axios/"
    },
];

export default function Page_About() {
    return (
        <div>
            <Page_Nav defaultKey={0}/>
            <br/>
            <Container>
                <Row>
                    {configAbout.map((items, index) => {
                        return (
                            <Col key={index}>
                                <Card style={{ width: "18rem" }}>
                                    <Card.Img
                                        variant={items.imgVariant}
                                        src={items.imgSrc}
                                    />
                                    <Card.Body>
                                        <Card.Title>
                                            <Link href={items.href}>{items.title}</Link>
                                            <span className="badge bg-secondary">
                                                New
                                            </span>
                                        </Card.Title>
                                        <Card.Text>{items.text}</Card.Text>
                                    </Card.Body>
                                </Card>
                            </Col>
                        );
                    })}
                </Row>
            </Container>
        </div>
    );
}
